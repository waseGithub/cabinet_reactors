=======
Credits
=======

Development Lead
----------------

* Jonas Berg https://github.com/pyhys

Contributors
------------

Significant contributions by:

* Aaron LaLonde
* Andres Ulloa
* Angelo Compagnucci
* Asier Abalos
* Austin Stover
* Dino
* Dominik Socha
* Edwin van den Oetelaar
* GitHub user: draput
* GitHub user: gnbl
* GitHub user: mrrs6
* GitHub user: noafterglow
* Luca Di Gregorio
* Matthias Bolte
* Michael Penza
* Peter
* Russ Garrett
* Simon Funke
